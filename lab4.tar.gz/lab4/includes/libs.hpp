#ifndef STDLIBS
#include <iostream>
#include "cdoublevector.hpp"
#include <fstream>
#define STDLIBS
#endif